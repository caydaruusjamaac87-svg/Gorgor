module github.com/antchfx/jsonquery

go 1.14

require (
	github.com/antchfx/xpath v1.3.2
	github.com/golang/groupcache v0.0.0-20210331224755-41bb18bfe9da
	github.com/stretchr/testify v1.8.4
)
